python -m venv venv
.\venv\scripts\Activate.ps1
python -m pip install --upgrade pip
pip install django
django-admin startproject defaults
Rename-Item -Path "defaults" -NewName "projeto"
cd projeto
python manage.py migrate
python manage.py startapp app_1
mkdir -p app_1\templates
New-Item -Path app_1\urls.py -ItemType File
New-Item -Path app_1\templates\index.html -ItemType File
mkdir -p static\css, static\js, static\img
New-Item -Path static\js\scripts.js -ItemType File
pip list
pip freeze > requirements.txt
python manage.py runserver