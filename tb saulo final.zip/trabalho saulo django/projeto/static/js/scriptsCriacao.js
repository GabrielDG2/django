let quill; // Declaração global para acesso em toda a aplicação


    // Inicializa o editor Quill
    quill = new Quill('#editor', {
        theme: 'snow',
        modules: {
            toolbar: [
                ['bold', 'italic', 'underline', 'strike'],
                [{ 'color': [] }],
                [{ 'font': [] }],
                [{ 'align': [] }],
            ],
        },
    }
)

    // Verifica se estamos editando uma nota
    var editandoNota = localStorage.getItem('editandoNota');
    alert('editandoNota:'+editandoNota)
    if (editandoNota) {
        var nota = JSON.parse(localStorage.getItem('notaSelecionada'));//tem que ser declarada como var
        localStorage.removeItem('editandoNota'); 
        localStorage.removeItem('notaSelecionada');
        
       
        if (nota) {
            document.getElementById('titulo').value = nota.titulo;
            quill.root.innerHTML = nota.conteudo; // Preenche o conteúdo no editor

        } else {
            console.error('Nota não encontrada no localStorage');
        }
    }

    
    
        window.adicionar_e_editar_Nota = function() {
        const titulo = document.getElementById('titulo').value;
        const conteudo = quill.root.innerHTML;
    
        if (editandoNota === 'true') {
            
            // Faz a requisição de edição
            fetch(`/editar_nota/${nota.id}/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                },
                body: JSON.stringify({
                    titulo: titulo,
                    conteudo: conteudo,
                })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        alert('Nota editada com sucesso!');
                        
                        window.location.assign('/'); // Volta para a página inicial
                    } else {
                        alert('Erro ao editar a nota: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro ao editar a nota:', error);
                    alert('Erro ao processar a requisição.');
                });
        } else {
            // Adiciona uma nova nota se não estiver editando
            fetch('/Adicionar_nota/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                },
                body: JSON.stringify({
                    titulo: titulo,
                    conteudo: conteudo,
                })
            })
                .then(response => response.json())
                .then(data => {
                    alert('Nota adicionada com sucesso!');
                    window.location.assign('/'); // Volta para a página inicial
                })
                .catch(error => {
                    console.error('Erro ao adicionar a nota:', error);
                    alert('Erro ao processar a requisição.');
                });
        }
    }
   
   

   
   
   
   
   
    
    