function MostrarNota() {
    fetch('/mostrar_notas/')
        .then(response => response.json())
        .then(data => {
            const listaNota = document.getElementById('listaNota');
            listaNota.innerHTML = '';

            data.notas.forEach(nota => {
                const li = document.createElement('li');
                li.classList.add('nota-item');  // Adiciona uma classe para cada item da lista

                // Cria os elementos de título e data com spans
                const tituloSpan = document.createElement('span');
                tituloSpan.classList.add('nota-titulo');
                tituloSpan.textContent = nota.titulo;

                const dataSpan = document.createElement('span');
                dataSpan.classList.add('nota-data');
                dataSpan.textContent = formatarData(nota.data);

              
                // Cria o botão de deletar
                const deletButton = document.createElement('button');
                deletButton.textContent = "Excluir";
                deletButton.onclick = () => deletar(nota.id);

                // Cria o botão de editar
                const editButton = document.createElement('button');
                editButton.textContent = "Editar";
                editButton.onclick = () => {
                    localStorage.setItem('notaSelecionada', JSON.stringify(nota));
                    localStorage.setItem('editandoNota', 'true');
                    window.location.assign('/criacao/');
                };

                // Adiciona os elementos criados ao <li>
                li.appendChild(tituloSpan);
                li.appendChild(document.createTextNode(' | '));  // Simula a coluna com |
                li.appendChild(dataSpan);
                li.appendChild(deletButton);
                li.appendChild(editButton);

                listaNota.appendChild(li);
            });
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao carregar notas.');
        });
}
MostrarNota()
function formatarData(dataISO) {
    const data = new Date(dataISO);
    return data.toLocaleString('pt-BR', {
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
    });
}


function deletar(id) {
    fetch(`/deletar_nota/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        }
    })
        .then(data => {
            alert('Nota excluída com sucesso!');
            MostrarNota(); // Atualiza a lista
        })
}