from django.contrib import admin
from .models import BlocoNota
 
admin.site.register(BlocoNota)