from django.shortcuts import render
from .models import BlocoNota
from django.http import JsonResponse
import json
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt


def inicial(request):
    return render(request, 'inicial.html')

def criacao(request):
    return render(request, 'criacao.html')
        
        
def Adicionar_nota(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            titulo = data.get('titulo')
            conteudo = data.get('conteudo')
            
            BlocoNota.objects.create(titulo = titulo, conteudo = conteudo, ) 
            

            return JsonResponse({'message': 'Nota adicionada com sucesso!'})
        except Exception as e:
            return JsonResponse({'error': 'Erro ao adicionar nota: ' + str(e)}, status=500)
    return JsonResponse({'error': 'Método não permitido'}, status=405)


def Mostrar_notas(request):
    # Pega todas as notas do banco de dados
    notas = BlocoNota.objects.all().values('id', 'titulo', 'data', 'conteudo') 
    notas_list = list(notas)  # Converte o QuerySet para uma lista de dicionários
    return JsonResponse({'notas': notas_list})


def Deletar_nota(request, id):
    if request.method == 'POST':
        nota = get_object_or_404(BlocoNota, id=id)
        nota.delete()  # Deleta a nota
        return JsonResponse({'message': 'Nota deletada com sucesso!'})
    return JsonResponse({'error': 'Método não permitido'}, status=405)


def editar_nota(request, nota_id):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            nota = BlocoNota.objects.get(id=nota_id)  # Busca a nota pelo ID
            nota.titulo = data.get('titulo', nota.titulo)  # Atualiza o título se enviado
            nota.conteudo = data.get('conteudo', nota.conteudo)  # Atualiza o conteúdo se enviado
            nota.save()  # Salva as alterações
            return JsonResponse({'status': 'success', 'message': 'Nota atualizada com sucesso!'})
        except BlocoNota.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Nota não encontrada.'}, status=404)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    else:
        return JsonResponse({'status': 'error', 'message': 'Método não permitido.'}, status=405)