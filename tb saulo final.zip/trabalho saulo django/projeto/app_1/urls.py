from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicial, name='inicial'),
    path('criacao/', views.criacao, name='criacao'),
    path('Adicionar_nota/', views.Adicionar_nota, name='Adicionar_nota'),
    path('mostrar_notas/', views.Mostrar_notas, name='Mostrar_notas'),
    path('deletar_nota/<int:id>', views.Deletar_nota, name='Deletar_nota'),
    path('editar_nota/<int:nota_id>/', views.editar_nota, name='editar_nota'),
]