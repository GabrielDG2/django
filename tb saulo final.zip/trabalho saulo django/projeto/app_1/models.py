from django.db import models

class  BlocoNota(models.Model):
    titulo = models.CharField(max_length=25)
    data = models.DateTimeField(auto_now=True)
    conteudo = models.TextField()

def __str__(self):
    return self.titulo